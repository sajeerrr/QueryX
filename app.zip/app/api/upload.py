from pathlib import Path
from fastapi import APIRouter, UploadFile, File


router = APIRouter()

UPLOAD_DIR = Path("uploads")

UPLOAD_DIR.mkdir(exist_ok=True)


@router.post("/upload")
async def upload_pdf(
    file: UploadFile = File(...)
):

    filepath = UPLOAD_DIR / file.filename

    with open(filepath, "wb") as f:

        f.write(await file.read())

    return {
        "filename": file.filename,
        "saved": True
    }